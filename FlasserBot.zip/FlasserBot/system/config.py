settings = {
	'token': '1492241023:AAHU5ck4bEITX2tBZn_fS0QDBKA1R4Q7z7w',
}