import requests
from bs4 import BeautifulSoup as bs


class Valute:
	table = {
		'dollar_course': 'Доллар 💵',
		'euro_course': 'Евро 💶',
		'dollar_euro_course': 'Все вместе 💰',
	}

	def __init__(self):
		self.headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 YaBrowser/20.9.3.136 Yowser/2.5 Safari/537.36"}
		self.url = "https://www.banki.ru/products/currency/"

		self.request = requests.get(url=self.url, headers=self.headers)
		self.soup = bs(self.request.content, 'html.parser')

	def get_dollar(self):
		dollar_container = self.soup.find_all('tr', {
			'class': 'cb-current-rates__list__item', 
			'class': 'cb-current-rates__switcher__item--active',
			'data-active-currency': '',
			'data-currency-code': 'USD',
			'data-currency-id': 840
		})[0].find_all('td')[1]

		return dollar_container.text

	def get_euro(self):
		euro_container = self.soup.find_all('tr', {
			'class': 'cb-current-rates__list__item',
			'data-currency-code': 'EUR',
			'data-currency-id': 978
		})[0].find_all('td')[1]

		return euro_container.text

	def get_dollar_euro(self):
		return {
			'dollar': self.get_dollar(), 
			'euro': self.get_euro()
		}