import requests 
from bs4 import BeautifulSoup as bs


class Virus():
	covid_table = {
		'russia': 'Россия 🇷🇺',
		'world': 'Мир 🌎'
	}

	def __init__(self):
		self.headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 YaBrowser/20.9.3.136 Yowser/2.5 Safari/537.36"}
		self.url = "https://стопкоронавирус.рф/" 

		self.request = requests.get(url=self.url, headers=self.headers)
		self.soup = bs(self.request.content, 'html.parser')

	def get_russia(self):
		local_soup = self.soup.find_all('div', {'class': 'cv-countdown__item-value'})
	
		covid_json = {
			'cases': local_soup[1].find_all('span')[0].text,
			'cases_this_day': local_soup[2].find_all('span')[0].text,
			'recovered': local_soup[3].find_all('span')[0].text,
			'deaths': local_soup[4].find_all('span')[0].text
		}

		return covid_json

	def get_world(self):
		pass

	def get_both_stats(self):
		stat_as_json = {
			'russia': self.get_russia(self),
			'world': self.get_world(self),
		}

		return stat_as_json