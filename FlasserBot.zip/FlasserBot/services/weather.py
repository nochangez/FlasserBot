import pyowm


class Weather():
	table = {
		'moscow': 'Москва',
		'spb': 'Санкт-Петербург'
	}

	def __init__(self):
		self.owm = pyowm.OWM('d42de34f7138cf738e7fa4534e2706a9') # config.settings["token_pyowm"])
		self.manager = self.owm.weather_manager()

	def get_weather(self, place_to_look):
		if place_to_look != None:
			observation = self.manager.weather_at_place(place_to_look)
			weather = observation.weather

			temperature_info = {
				'status': weather.detailed_status,
				'wind': weather.wind(),
				'temperature': weather.temperature('celsius'),
				'rain': weather.rain,
			}

			return temperature_info
		else:
			return None