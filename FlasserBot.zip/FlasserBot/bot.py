from datetime import datetime, timedelta
import logging

from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ContentType, KeyboardButton, \
		ReplyKeyboardMarkup, InlineKeyboardMarkup
from aiogram.dispatcher.filters.state import State, StatesGroup

from system import config
from services.valute import Valute
from services.weather import Weather
from services.covid19 import Virus


# logging
logging.basicConfig(level=logging.INFO)

# init bot
bot = Bot(token=config.settings["token"])
dp = Dispatcher(bot)


@dp.message_handler(commands=["start"])
async def start(message: types.Message):
	# money rate
	currency_button = KeyboardButton('Курс валют 💸')

	# weather
	weather_button = KeyboardButton('Погода 🌞')

	# donate button
	donate_button = KeyboardButton('Заплатить налог 💲')

	# dev contacts button
	contact_button = KeyboardButton('Контакты 🤙')

	# covid19
	covid19_button = KeyboardButton('Коронавирус 🦠')
	
	panel = ReplyKeyboardMarkup(
		resize_keyboard=True, one_time_keyboard=True
	).add(currency_button, weather_button).add(covid19_button).add(donate_button, contact_button)

	await message.answer('Выберите одно из действий 🎛', reply_markup=panel)


@dp.message_handler(content_types=[ContentType.TEXT])
async def catch_links(message: types.Message):
	if message.chat.type != 'private':
		if message.entities != None:
			for entity in message.entities:
				if entity.type in ['url', 'text_link']:
					await bot.send_message(
						message.chat.id,
						text=(
							f'@{message.from_user.username}, '
							'Вам запрещено отправлять ссылки в этом чате.'
						)
					)
					await bot.delete_message(
						message.chat.id, 
						message.message_id
					)
				else:
					return

	if message.text == 'Курс валют 💸':
		# dollar
		dollar_button = KeyboardButton(
			"Доллар 💵", 
			callback_data="dollar_course"
		)

		# euro
		euro_button = KeyboardButton(
			"Евро 💶", 
			callback_data="euro_course"
		)

		# dollar and euro currency
		euro_dollar_button = KeyboardButton(
			"Все вместе 💰", 
			callback_data="dollar_euro_course"
		)

		# currency keyboard
		currency_panel = InlineKeyboardMarkup(
			resize_keyboard=True
		).add(dollar_button, euro_button).add(euro_dollar_button)

		await bot.send_message(
			message.chat.id,
			"Выберите валюту, курс которой Вас интересует",
			reply_markup=currency_panel
		)
	elif message.text == 'Контакты 🤙':
		# 1st floor
		vk_button = KeyboardButton("Гугол эаэаэы 📞", url="https://www.google.com/")
		tg_button = KeyboardButton("Тг 💌", url="t.me/knxwn/")

		# 2nd floor
		test_button = KeyboardButton('test', callback_data='test')

		# contacts keyboard
		dev_contacts_kb = InlineKeyboardMarkup(
			resize_keyboard=True
		).add(vk_button, tg_button).add(test_button)

		await bot.send_message(
			message.chat.id,
			'Меня можно найти тут 🙃', 
			reply_markup=dev_contacts_kb
		)
	elif message.text == 'Заплатить налог 💲':
		# 1st floor
		qiwy_button = KeyboardButton(
			'Qiwy 🥝', url="https://qiwi.com/n/WAYEA743"
		)
		sber_button = KeyboardButton(
			'Сбербанк 🥦', callback_data='test_sber'
		)

		# donate keyboard
		donate_keyboard = InlineKeyboardMarkup(
			resize_keyboard=True
		).add(qiwy_button, sber_button)

		await bot.send_message(
			message.chat.id,
			'Мне надо жрать дай денег эаэа :(',
			reply_markup=donate_keyboard
		)
	elif message.text == 'Погода 🌞':
		# 1st floor
		moscow_button = KeyboardButton(
			'Москва 🌆', callback_data='weather moscow'
		)
		spb_button = KeyboardButton(
			'СПБ 🏫', callback_data='weather spb'
		)

		# avaliable cities keyboard
		cities_keyboard = InlineKeyboardMarkup(
			resize_keyboard=True
		).add(moscow_button, spb_button)

		await bot.send_message(
			message.chat.id,
			text=('Мини <b>сервис погоды</b>.\n\n'
				  'Выберите город, погода которого '
				  'Вас интересует'
			),
			parse_mode='HTML',
			reply_markup=cities_keyboard
		)
	elif message.text == 'Коронавирус 🦠':
		# 1st floor
		covid_data_source_button = KeyboardButton(
			'Источник 🧬', url="https://стопкоронавирус.рф/" # https://covid19.rosminzdrav.ru/"
		)

		# 2nd floor
		russia_state_button = KeyboardButton(
			'Россия 🇷🇺', callback_data='covid russia'
		)
		world_state_button = KeyboardButton(
			'Мир 🌎', callback_data='covid world'
		)

		# covid19 keyboard
		statistic_keyboard = InlineKeyboardMarkup(
			resize_keyboard=True
		).add(covid_data_source_button).add(russia_state_button, world_state_button)

		await bot.send_message(
			message.chat.id,
			'Статистика по коронавирусу:\n\nСкоро будет',
			reply_markup=statistic_keyboard
		)


@dp.callback_query_handler(lambda callback_query: True)
async def catch_buttons(callback_query: types.CallbackQuery):
	try:
		if (callback_query.data == 'dollar_course' or 
				callback_query.data == 'euro_course' or 
						callback_query.data == 'dollar_euro_course'):
			await bot.answer_callback_query(
				callback_query.id,
				show_alert=False,
				text='Секундочку...'
			)

			data = callback_query.data	
			valute_object = Valute()

			choosed_currency = valute_object.table[callback_query.data]

			await bot.edit_message_text(
				chat_id=callback_query.message.chat.id,
				message_id=callback_query.message.message_id,
				text=f"Выбрано: <b>{choosed_currency}</b>",
				parse_mode='HTML',
				reply_markup=None
			)

			if data == 'dollar_course':
				dollar_course = valute_object.get_dollar()

				await callback_query.message.answer(
					f'<b>Курс доллара на сегодня</b>\n\n<b><i>{dollar_course}</i></b> рубля',
					parse_mode='HTML'
				)
			elif data == 'euro_course':
				euro_course = valute_object.get_euro()

				await callback_query.message.answer(
					f'<u>Курс евро на сегодня</u>\n\n<b><i>{euro_course}</i></b> рубля',
					parse_mode='HTML'
				)
			else:
				both_currencies = valute_object.get_dollar_euro()

				dollar = both_currencies['dollar']
				euro = both_currencies['euro']

				await callback_query.message.answer(
					text=('<b>Курс валют на сегодня</b>\n\n<u>Доллар</u>: '
						  f'<b><i>{dollar}</i> рубля</b>\n<u>Евро</u>: '
						  f'<b><i>{euro}</i> рубля</b>'),
					parse_mode='HTML'
				) 
		elif callback_query.data == 'test':
			await bot.answer_callback_query(
				callback_query.id, 
				show_alert=False, 
				text='it works'
			)
		elif callback_query.data == 'test_sber':
			await bot.answer_callback_query(
				callback_query.id, 
				show_alert=False,
				text='скоро эаэ'
			)
		elif callback_query.data.split()[0] == 'weather':	
			await bot.answer_callback_query(
				callback_query.id,
				show_alert=False,
				text='Секундочку...'
			)

			weather_object = Weather()
			choosed_city = weather_object.table[callback_query.data.split()[1]]

			await bot.edit_message_text(
				chat_id=callback_query.message.chat.id,
				message_id=callback_query.message.message_id,
				text=f"Выбран город: <b>{choosed_city}</b>",
				parse_mode='HTML',
				reply_markup=None
			)

			weather = weather_object.get_weather(choosed_city)

			# temperature
			temp = weather['temperature']['temp']
			max_temp = weather['temperature']['temp_max']
			min_temp = weather['temperature']['temp_min']
			feels_like = weather['temperature']['feels_like']

			# wind
			wind_speed = weather['wind']['speed']

			weather_message = (
				f'<b>Погода в городе {choosed_city}</b>'
				f'\n\n<b>Градусник</b> 🌡\n<u>Температура</u>: <b><i>{temp}</i></b> '
				f'градуса.\n<u>Макс. температура</u>: <b><i>{max_temp}'
				f'</i></b> градусов.\n<u>Мин. температура</u>: <b><i>{min_temp}'
				f'</i></b> градусов.\n<u>По ощущениям</u>: <b><i>{feels_like}'
				'</i></b> градусов.\n\n<b>Ветер</b> 💨\n<u>Скорость</u>: '
				f'<b><i>{wind_speed}</i></b> м/с.'  
			)

			await callback_query.message.answer(
				weather_message,
				parse_mode='HTML'
			)
		elif callback_query.data.split()[0] == 'covid':
			await bot.answer_callback_query(
				callback_query.id,
				show_alert=False,
				text='Секундочку...'
			)

			data = callback_query.data.split()[1]
			virus_object = Virus()
			choosed_state = virus_object.covid_table[callback_query.data.split()[1]]

			await bot.edit_message_text(
				chat_id=callback_query.message.chat.id,
				message_id=callback_query.message.message_id,
				text=f"Выбрана статистика: <b>{choosed_state}</b>",
				parse_mode='HTML',
				reply_markup=None
			)

			if data == 'russia':
				state = virus_object.get_russia()

				cases = state['cases']
				cases_this_day = state['cases_this_day']
				recovered = state['recovered']
				deaths = state['deaths']

				covid_message = (
					'<b>Статистика по коронавирусу в России</b>\n\n'
					f'<u>Заразилось</u>: <b><i>{cases}</i></b>'
					f'\n<u>Заразилось сегодня</u>: <b><i>{cases_this_day}</i></b> '
					f'\n<u>Выздоровело</u>: <b><i>{recovered}</i></b> '
					f'\n<u>Умерло</u>: <b><i>{deaths}</i></b>'
				)

				await callback_query.message.answer(
					covid_message,
					parse_mode='HTML'
				)
			elif data == 'world':
				await callback_query.message.answer(
					'Скоро сделаю.'
				)
	except Exception as error:
		print(repr(error))

if __name__ == '__main__':
	executor.start_polling(dp, skip_updates=True)